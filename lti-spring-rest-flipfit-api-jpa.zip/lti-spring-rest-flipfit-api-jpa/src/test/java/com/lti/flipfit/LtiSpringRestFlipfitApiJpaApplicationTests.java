package com.lti.flipfit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LtiSpringRestFlipfitApiJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
