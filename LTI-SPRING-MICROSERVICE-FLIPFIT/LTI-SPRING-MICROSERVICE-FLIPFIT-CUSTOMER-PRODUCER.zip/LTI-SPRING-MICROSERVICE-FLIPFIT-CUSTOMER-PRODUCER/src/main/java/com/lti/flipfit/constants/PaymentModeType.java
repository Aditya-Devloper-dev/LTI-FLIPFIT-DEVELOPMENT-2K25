package com.lti.flipfit.constants;

public enum PaymentModeType {
    CARD,
    UPI,
    NETBANKING
}
