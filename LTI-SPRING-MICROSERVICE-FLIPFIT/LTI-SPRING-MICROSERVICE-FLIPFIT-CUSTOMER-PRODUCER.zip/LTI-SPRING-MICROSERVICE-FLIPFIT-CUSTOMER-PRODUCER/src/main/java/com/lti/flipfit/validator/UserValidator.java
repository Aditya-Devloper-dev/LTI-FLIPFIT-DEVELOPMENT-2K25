package com.lti.flipfit.validator;

/**
 * Author :
 * Version : 1.0
 * Description : Validator class for User operations.
 */

import org.springframework.stereotype.Component;

@Component
public class UserValidator {
    public void validateUser(Object user) {
        // Validation logic
    }
}
