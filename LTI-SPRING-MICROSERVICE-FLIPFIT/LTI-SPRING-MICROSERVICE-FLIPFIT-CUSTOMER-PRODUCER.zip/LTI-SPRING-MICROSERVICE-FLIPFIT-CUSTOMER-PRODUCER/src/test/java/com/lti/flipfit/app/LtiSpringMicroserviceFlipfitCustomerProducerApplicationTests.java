package com.lti.flipfit.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LtiSpringMicroserviceFlipfitCustomerProducerApplicationTests {

	@Test
	void contextLoads() {
	}

}
