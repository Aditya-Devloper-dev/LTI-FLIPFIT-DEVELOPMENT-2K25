package com.lti.flipfit.exceptions.user;

/**
 * Author :
 * Version : 1.0
 * Description : Exception thrown when user already exists.
 */

public class UserAlreadyExistsException extends RuntimeException {

    private final String errorCode = "USER_ALREADY_EXISTS";

    public UserAlreadyExistsException(String message) {
        super(message);
    }

    public String getErrorCode() {
        return errorCode;
    }
}
