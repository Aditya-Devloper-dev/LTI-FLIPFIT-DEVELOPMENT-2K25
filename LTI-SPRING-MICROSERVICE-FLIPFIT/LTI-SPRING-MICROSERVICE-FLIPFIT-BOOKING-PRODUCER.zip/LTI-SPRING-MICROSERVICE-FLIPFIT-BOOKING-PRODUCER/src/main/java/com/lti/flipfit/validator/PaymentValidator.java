package com.lti.flipfit.validator;

/**
 * Author :
 * Version : 1.0
 * Description : Validator class for Payment operations.
 */

import org.springframework.stereotype.Component;

@Component
public class PaymentValidator {
    public void validatePayment(Object payment) {
        // Validation logic
    }
}
